import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class Subtask {
    String name;
    boolean isCompleted;

    Subtask(String name) {
        this.name = name;
        this.isCompleted = false;
    }

    void markCompleted() {
        this.isCompleted = true;
    }

    @Override
    public String toString() {
        return (isCompleted ? "[Completed] " : "[Pending] ") + name;
    }
}

class Task {
    String name;
    boolean isCompleted;
    HashMap<Integer, Subtask> subtasks;
    private int subtaskCounter = 0;

    Task(String name) {
        this.name = name;
        this.isCompleted = false;
        this.subtasks = new HashMap<>();
    }

    void addSubtask(String subtaskName) {
        subtasks.put(++subtaskCounter, new Subtask(subtaskName));
    }

    void deleteSubtask(int index) {
        if (subtasks.containsKey(index)) {
            subtasks.remove(index);
        } else {
            System.out.println("Invalid subtask index.");
        }
    }

    void markCompleted() {
        this.isCompleted = true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append((isCompleted ? "[Completed] " : "[Pending] ") + name + "\n");
        for (Map.Entry<Integer, Subtask> entry : subtasks.entrySet()) {
            sb.append("  ").append(entry.getKey()).append(". ").append(entry.getValue()).append("\n");
        }
        return sb.toString();
    }
}

class RecurringTask {
    String name;
    int totalDays;
    int hoursPerDay;
    LocalDate startDate;

    RecurringTask(String name, int totalDays, int hoursPerDay) {
        this.name = name;
        this.totalDays = totalDays;
        this.hoursPerDay = hoursPerDay;
        this.startDate = LocalDate.now();
    }

    int daysCompleted() {
        return (int) ChronoUnit.DAYS.between(startDate, LocalDate.now());
    }

    int daysRemaining() {
        return totalDays - daysCompleted();
    }

    boolean isCompleted() {
        return daysCompleted() >= totalDays;
    }

    @Override
    public String toString() {
        return (isCompleted() ? "[Completed] " : "[Pending] ") + name + " - " + totalDays + " days, " + hoursPerDay + " hours/day, " + daysCompleted() + " days completed, " + daysRemaining() + " days remaining";
    }

    void markCompleted() {
        // Assuming a method to mark the recurring task as completed
    }
}

public class TaskManagementSystem {
    static TreeMap<Integer, Task> tasks = new TreeMap<>();
    static TreeMap<Integer, RecurringTask> recurringTasks = new TreeMap<>();
    static Scanner scanner = new Scanner(System.in);
    private static int taskCounter = 0;
    private static int recurringTaskCounter = 0;
    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static LocalTime notificationTime = LocalTime.of(9, 0); // default notification time is 9:00 AM

    public static void main(String[] args) {
        // Schedule the reminder task to run every minute
        scheduler.scheduleAtFixedRate(TaskManagementSystem::checkNotificationTime, 0, 1, TimeUnit.MINUTES);

        while (true) {
            System.out.println("Task Management System");
            System.out.println("1. Add New Task");
            System.out.println("2. Add Subtask to a Task");
            System.out.println("3. Delete Task");
            System.out.println("4. Delete Subtask");
            System.out.println("5. Mark Task Completed");
            System.out.println("6. Mark Subtask Completed");
            System.out.println("7. View All Tasks");
            System.out.println("8. Manage Recurring Tasks");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (option) {
                case 1:
                    addTask();
                    break;
                case 2:
                    addSubtask();
                    break;
                case 3:
                    deleteTask();
                    break;
                case 4:
                    deleteSubtask();
                    break;
                case 5:
                    markTaskCompleted();
                    break;
                case 6:
                    markSubtaskCompleted();
                    break;
                case 7:
                    viewAllTasks();
                    break;
                case 8:
                    manageRecurringTasks();
                    break;
                case 9:
                    System.out.println("Exiting...");
                    scheduler.shutdown();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    static void addTask() {
        System.out.print("Enter task name: ");
        String taskName = scanner.nextLine();
        tasks.put(++taskCounter, new Task(taskName));
    }

    static void addSubtask() {
        viewAllTasks();
        System.out.print("Select task number to add subtask: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (tasks.containsKey(taskIndex)) {
            System.out.print("Enter subtask name: ");
            String subtaskName = scanner.nextLine();
            tasks.get(taskIndex).addSubtask(subtaskName);
        } else {
            System.out.println("Invalid task index.");
        }
    }

    static void deleteTask() {
        viewAllTasks();
        System.out.print("Select task number to delete: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (tasks.containsKey(taskIndex)) {
            tasks.remove(taskIndex);
        } else {
            System.out.println("Invalid task index.");
        }
    }

    static void deleteSubtask() {
        viewAllTasks();
        System.out.print("Select task number: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (tasks.containsKey(taskIndex)) {
            System.out.println(tasks.get(taskIndex));
            System.out.print("Select subtask number to delete: ");
            int subtaskIndex = scanner.nextInt();
            scanner.nextLine(); // consume newline

            tasks.get(taskIndex).deleteSubtask(subtaskIndex);
        } else {
            System.out.println("Invalid task index.");
        }
    }

    static void markTaskCompleted() {
        viewAllTasks();
        System.out.print("Select task number to mark as completed: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (tasks.containsKey(taskIndex)) {
            tasks.get(taskIndex).markCompleted();
        } else {
            System.out.println("Invalid task index.");
        }
    }

    static void markSubtaskCompleted() {
        viewAllTasks();
        System.out.print("Select task number: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (tasks.containsKey(taskIndex)) {
            System.out.println(tasks.get(taskIndex));
            System.out.print("Select subtask number to mark as completed: ");
            int subtaskIndex = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (tasks.get(taskIndex).subtasks.containsKey(subtaskIndex)) {
                tasks.get(taskIndex).subtasks.get(subtaskIndex).markCompleted();
            } else {
                System.out.println("Invalid subtask index.");
            }
        } else {
            System.out.println("Invalid task index.");
        }
    }

    static void viewAllTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
        } else {
            for (Map.Entry<Integer, Task> entry : tasks.entrySet()) {
                System.out.println(entry.getKey() + ". " + entry.getValue());
            }
        }
    }

    static void changeNotificationTime() {
        System.out.print("Enter notification hour (0-23): ");
        int hour = scanner.nextInt();
        System.out.print("Enter notification minute (0-59): ");
        int minute = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (hour >= 0 && hour < 24 && minute >= 0 && minute < 60) {
            notificationTime = LocalTime.of(hour, minute);
            System.out.println("Notification time changed to " + notificationTime);
        } else {
            System.out.println("Invalid time entered.");
        }
    }

    static void checkNotificationTime() {
        LocalTime currentTime = LocalTime.now();

        if (currentTime.getHour() == notificationTime.getHour() && currentTime.getMinute() == notificationTime.getMinute()) {
            sendReminder();
        }
    }

    static void sendReminder() {
        System.out.println("\nReminder: It's " + notificationTime + "! Here are your pending recurring tasks:");

        for (Map.Entry<Integer, RecurringTask> entry : recurringTasks.entrySet()) {
            RecurringTask recurringTask = entry.getValue();
            if (!recurringTask.isCompleted()) {
                System.out.println(entry.getKey() + ". " + recurringTask);
                if (recurringTask.daysCompleted() >= recurringTask.totalDays) {
                    recurringTask.markCompleted();
                    System.out.println("    [Completed] " + recurringTask.name + " - " + recurringTask.totalDays + " days, " + recurringTask.hoursPerDay + " hours/day, " + recurringTask.totalDays + " days completed");
                }
            }
        }

        System.out.println();
    }

    static void manageRecurringTasks() {
        System.out.println("Recurring Task Management");
        System.out.println("1. Add New Recurring Task");
        System.out.println("2. Remove a Recurring Task");
        System.out.println("3. View Recurring Tasks");
        System.out.println("4. Change Notification Time"); // Added option here
        System.out.print("Choose an option: ");
        int option = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (option) {
            case 1:
                addRecurringTask();
                break;
            case 2:
                removeRecurringTask();
                break;
            case 3:
                viewRecurringTasks();
                break;
            case 4: // Handle the new option here
                changeNotificationTime();
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    static void addRecurringTask() {
        System.out.print("Enter recurring task name: ");
        String taskName = scanner.nextLine();
        System.out.print("Enter number of days for this task: ");
        int totalDays = scanner.nextInt();
        System.out.print("Enter number of hours per day for this task: ");
        int hoursPerDay = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (totalDays > 0 && hoursPerDay > 0) {
            recurringTasks.put(++recurringTaskCounter, new RecurringTask(taskName, totalDays, hoursPerDay));
        } else {
            System.out.println("Invalid input. Days and hours must be positive.");
        }
    }

    static void removeRecurringTask() {
        viewRecurringTasks();
        System.out.print("Select recurring task number to remove: ");
        int taskIndex = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (recurringTasks.containsKey(taskIndex)) {
            recurringTasks.remove(taskIndex);
        } else {
            System.out.println("Invalid recurring task index.");
        }
    }

    static void viewRecurringTasks() {
        if (recurringTasks.isEmpty()) {
            System.out.println("No recurring tasks available.");
        } else {
            for (Map.Entry<Integer, RecurringTask> entry : recurringTasks.entrySet()) {
                System.out.println(entry.getKey() + ". " + entry.getValue());
            }
        }
    }
}
