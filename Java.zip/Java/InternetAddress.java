
public class InternetAddress {

}
